from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login as dlogin, logout as dlogout
from mymember.models import Member

def home(request):
    if 'idx' not in request.session.keys():
        return render(request, 'mymember/login.html')
    else:
        return render(request, 'mymember/main.html')

def join(request):
    if "file1" in request.FILES:
        file = request.FILES["file1"]
        file_name = file._name
        fp = open("%s%s" % (UPLOAD_DIR, file_name), "wb")
        for chunk in file.chunks():
            fp.write(chunk)
            fp.close()
    else:
        file_name = "-"
    if request.method == 'POST':
        userid = request.POST['userid']
        passwd = request.POST['passwd']
        name = request.POST['name']
        email = request.POST['email']
        address = request.POST['address']
        tel = request.POST['tel']
        picture_url = file_name
        Member(userid=userid, passwd=passwd, name=name,
               email=email, address=address, tel=tel, picture_url=picture_url).save()
        request.session['userid'] = userid
        request.session['name'] = name
        return render(request, 'mymember/main.html')
    else:
        return render(request, 'mymember/join.html')

# def join(request):
#     if "file1" in request.FILES:
#         file = request.FILES["file1"]
#         file_name = file._name
#         fp = open("%s%s" % (UPLOAD_DIR, file_name), "wb")
#         for chunk in file.chunks():
#             fp.write(chunk)
#             fp.close()
#         else:
#             file_name = "-"
#             memb = Member(userid=request.POST["userid"],
#                          passwd=request.POST["passwd"],
#                          name=request.POST["name"],
#                          email=request.POST["email"],
#                          address=request.POST["address"],
#                          tel=request.POST["tel"],
#                          picture_url=file_name)
#             memb.save()
#             return redirect('/mymember')


def login(request):
    if request.method == 'POST':
        #idx = request.POST['idx']
        userid = request.POST['userid']
        passwd = request.POST['passwd']
        row = Member.objects.filter(userid=userid, passwd=passwd).first()
        if row is not None:
            request.session['userid'] = userid
            request.session['idx'] = row.idx
            #request.session['name'] = row.name
            return render(request, 'mymember/main.html')
        else:
            return render(request, 'mymember/login.html', {'msg': '아이디 또는 비밀번호가 일치하지 않습니다. 다시 한번 로그인해 주세요'})
    else:
        return render(request, 'mymember/login.html')


def logout(request):
    request.session.clear()
    return redirect('/mymember')

def custlist(request):
        item = Member.objects.order_by("name")
        return render(request, "mymember/custlist.html", {"item": item})

# def custlist(request):
#     if request.session.get("userid", False):
#         id = request.GET.get('userid')
#         item = Member.objects.get(userid = id)
#         return render(request, "mymember/custlist.html", {"item": item})
#     else:
#         return redirect("/mymember")


# def xray_insert(request):
#     if "file1" in request.FILES:
#         file = request.FILES["file1"]
#         file_name = file._name
#         fp = open("%s%s" % (UPLOAD_DIR, file_name), "wb")
#         for chunk in file.chunks():
#             fp.write(chunk)
#             fp.close()
#         else:
#             file_name = "-"
#             memb = Member(userid=request.POST["userid"],
#                          passwd=request.POST["passwd"],
#                          name=request.POST["name"],
#                          email=request.POST["email"],
#                          address=request.POST["address"],
#                          tel=request.POST["tel"],
#                          picture_url=file_name)
#             memb.save()
#             return redirect('/mymember')

def update(request):
    id = request.POST['idx']
    row_src = Member.objects.get(idx=id)
    p_url = row_src.picture_url
    if "file1" in request.FILES:
        file = request.FILES["file1"]
        p_url = file._name
        fp = open("%s%s" % (UPLOAD_DIR, p_url), "wb")
        for chunk in file.chunks():
            fp.write(chunk)
            fp.close()
            row_new = Member(idx=id,
                             passwd=request.POST["passwd"],
                             name=request.POST["name"],
                             email=request.POST["email"],
                             address=request.POST["address"],
                             tel=request.POST["tel"],
                             picture_url=p_url)
            row_new.save()
            return redirect("/mymember")

def detail(request):
    #id = request.POST['idx']
    memb = Member.objects.order_by("idx")
    return render(request, "mymember/detail.html",{"memb":memb})


    # if request.method == 'POST':
    #     try:
    #         Member.objects.get(idx=request.POST['idx'])
    #     except  Member.DoseNotExist:
    #         print('에러')
    #         return render(request, "mymember/detail.html")
    # else:
    #     return render(request, 'mymember/detail.html')

# def update(request):
#     memb = Member(
#         passwd=request.POST["passwd"],
#         name=request.POST["name"],
#         email=request.POST["email"],
#         address=request.POST["address"],
#         tel=request.POST["tel"],
#     )
#     memb.save()
#     return redirect("/mymember")


def delete(request):
    Member.objects.get(userid=request.POST["userid"]).delete()
    return redirect("/mymember")