from django.db import models

class Member(models.Model):
    idx = models.AutoField(primary_key=True)
    userid = models.CharField(max_length=50, null=False)
    passwd = models.CharField(max_length=50, null=False)
    name = models.CharField(max_length=20, null=False)
    email = models.CharField(max_length=50, blank=True, null=True)
    address = models.CharField(max_length=20, null=True)
    tel = models.CharField(max_length=20, null=True)
    picture_url = models.CharField(null=True, max_length=150)
