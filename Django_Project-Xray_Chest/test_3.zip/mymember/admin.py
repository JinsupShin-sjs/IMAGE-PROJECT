from django.contrib import admin
from mymember.models import Member


class MemberAdmin(admin.ModelAdmin):
    list_display = ("idx", "userid", "passwd","name", "email", "address","tel","picture_url")


admin.site.register(Member, MemberAdmin)