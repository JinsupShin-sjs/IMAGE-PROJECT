from django.apps import AppConfig


class MymemberConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "mymember"
